# Build JARVIS from your Pixel

You do NOT need to install Gradle on the Pixel for this workflow.

1. Open your GitHub repository in Chrome.
2. Upload the contents of this project to the repository's `main` branch.
3. Make sure `.github/workflows/android.yml` is preserved exactly.
4. Open the repository's **Actions** tab.
5. Select **Build JARVIS APK**.
6. Run the workflow if it did not start automatically.
7. Wait for the green check.
8. Open the completed run.
9. Under **Artifacts**, download **JARVIS-debug-APK**.
10. Extract the artifact and tap `app-debug.apk` on your Pixel.
11. Allow installation from the browser/file manager when Android asks.
12. Open JARVIS and grant microphone + notification permissions.
13. Enable JARVIS under Android Settings → Accessibility → Downloaded apps.
14. Return to JARVIS and tap Activate.

The build workflow uses JDK 17, Gradle 8.10.2, Android API 35 and Build Tools 35.0.0 in GitHub's cloud runner.
