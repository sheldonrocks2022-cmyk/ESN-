# ESN JARVIS — Full Android Prototype

This source package is the expanded JARVIS prototype based on the supplied project files.

## What is implemented

- Persistent foreground microphone service
- Continuous speech-recognition loop
- Wake phrase: `JARVIS`
- `JARVIS, Code 101` privacy shutdown
- Reopening the JARVIS UI as the deliberate reactivation path after Code 101
- Android AccessibilityService phone-control layer
- Global Home / Back / Recents
- Click visible UI text
- Type into the active editable field
- Scroll up/down
- Read accessible text from the current screen
- Dynamic installed-app launching by app name
- Web and YouTube search
- Volume up/down, mute and unmute
- Settings launcher
- Persistent foreground notification
- Android permission handling
- GitHub Actions debug APK workflow

## Android reality

This is a real Android service architecture, but it is not root access and cannot bypass Android security boundaries.

Accessibility control only works where Android exposes controls to the accessibility framework. Some apps, secure screens, DRM surfaces, password fields, banking flows, and other protected interfaces can intentionally block automation.

The microphone service must be explicitly activated by the user. Android also controls when background microphone foreground services may be started. Code 101 actually stops microphone recognition; JARVIS therefore cannot hear another spoken activation phrase while fully offline. Reopening the app is the explicit reactivation path.

The current wake-word implementation uses Android SpeechRecognizer sessions. A future production version should replace this with a dedicated on-device wake-word engine for lower latency, lower network dependence, and better privacy.
