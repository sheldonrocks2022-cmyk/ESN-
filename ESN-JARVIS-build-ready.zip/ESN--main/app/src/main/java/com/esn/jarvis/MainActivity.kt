package com.esn.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    private var active by mutableStateOf(false)
    private var message by mutableStateOf("JARVIS is offline.")

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                message = "Microphone ready."
            } else {
                message = "Microphone permission is required for voice control."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()
        setContent { JarvisScreen() }
    }

    override fun onResume() {
        super.onResume()
        active = JarvisVoiceService.isActive(this)
        message = if (active) {
            "JARVIS is listening in the background. Say JARVIS."
        } else {
            "JARVIS is offline. Tap Activate to start the voice service."
        }
    }

    @Composable
    private fun JarvisScreen() {
        MaterialTheme {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF061426)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(40.dp))

                    Text(
                        "JARVIS",
                        color = Color(0xFF7DEFF2),
                        fontSize = 42.sp
                    )

                    Text(
                        "PERSISTENT PHONE ASSISTANT",
                        color = Color.White,
                        fontSize = 13.sp
                    )

                    Spacer(Modifier.height(30.dp))

                    Text(
                        if (active) "VOICE SYSTEM: ACTIVE"
                        else "VOICE SYSTEM: OFFLINE",
                        color = Color(0xFF42E8F4),
                        fontSize = 18.sp
                    )

                    Spacer(Modifier.height(10.dp))

                    Text(
                        message,
                        color = Color(0xFFD6E2F0),
                        fontSize = 15.sp
                    )

                    Spacer(Modifier.height(24.dp))

                    Button(
                        onClick = { toggleVoice() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (active) "Deactivate JARVIS" else "Activate JARVIS")
                    }

                    Spacer(Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Enable Phone Control")
                    }

                    Spacer(Modifier.height(24.dp))

                    Text(
                        "Voice examples:\n" +
                            "• “JARVIS, open Discord”\n" +
                            "• “JARVIS, go home”\n" +
                            "• “JARVIS, scroll down”\n" +
                            "• “JARVIS, click Send”\n" +
                            "• “JARVIS, type hello”\n" +
                            "• “JARVIS, read screen”\n" +
                            "• “JARVIS, search the web for …”\n\n" +
                            "Say “JARVIS, Code 101” to immediately stop microphone listening. " +
                            "After Code 101, reopening this app is the deliberate reactivation path.",
                        color = Color(0xFFB8C7D9),
                        fontSize = 13.sp
                    )
                }
            }
        }
    }

    private fun toggleVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionsIfNeeded()
            return
        }

        val intent = Intent(this, JarvisVoiceService::class.java)

        if (!active) {
            intent.action = JarvisVoiceService.ACTION_START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            active = true
            message = "JARVIS is listening in the background. Say JARVIS."
        } else {
            intent.action = JarvisVoiceService.ACTION_STOP
            startService(intent)
            active = false
            message = "JARVIS is offline."
        }
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = mutableListOf<String>()

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permissions += Manifest.permission.RECORD_AUDIO
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }

        if (permissions.isNotEmpty()) {
            permissionLauncher.launch(permissions.toTypedArray())
        }
    }
}
