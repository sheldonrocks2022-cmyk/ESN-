package com.esn.jarvis

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
            private set

        fun clickText(text: String): Boolean =
            instance?.clickTextInternal(text) == true

        fun typeText(text: String): Boolean =
            instance?.typeTextInternal(text) == true

        fun back(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_BACK) == true

        fun home(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_HOME) == true

        fun recents(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) == true

        fun scrollForward(): Boolean =
            instance?.scrollInternal(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true

        fun scrollBackward(): Boolean =
            instance?.scrollInternal(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) == true

        fun readScreen(): String =
            instance?.readScreenInternal().orEmpty()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    private fun clickTextInternal(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val wanted = text.trim()
        if (wanted.isBlank()) return false

        val nodes = root.findAccessibilityNodeInfosByText(wanted)
        for (node in nodes) {
            if (node.isVisibleToUser && node.isEnabled) {
                if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }

                var parent = node.parent
                while (parent != null) {
                    if (parent.isVisibleToUser &&
                        parent.isEnabled &&
                        parent.isClickable &&
                        parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    ) {
                        return true
                    }
                    parent = parent.parent
                }
            }
        }
        return false
    }

    private fun typeTextInternal(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val editable = findEditable(root) ?: return false
        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return editable.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun scrollInternal(action: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        return node.performAction(action)
    }

    private fun readScreenInternal(): String {
        val root = rootInActiveWindow ?: return ""
        val parts = ArrayList<String>()
        collectVisibleText(root, parts)

        return parts
            .distinct()
            .filter { it.isNotBlank() }
            .joinToString(". ")
            .take(1600)
    }

    private fun collectVisibleText(
        node: AccessibilityNodeInfo,
        output: MutableList<String>
    ) {
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(output::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(output::add)
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectVisibleText(child, output)
            }
        }
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isEnabled && node.isVisibleToUser) return node

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findEditable(child)?.let { return it }
            }
        }
        return null
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable && node.isEnabled && node.isVisibleToUser) return node

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findScrollable(child)?.let { return it }
            }
        }
        return null
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
}
