package com.esn.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class JarvisVoiceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "com.esn.jarvis.START"
        const val ACTION_STOP = "com.esn.jarvis.STOP"

        private const val CHANNEL_ID = "jarvis_voice"
        private const val NOTIFICATION_ID = 101
        private const val PREFS = "jarvis"
        private const val ACTIVE = "active"
        private const val WAKE = "jarvis"

        fun requestPrivacyMode(context: Context) {
            context.startService(
                Intent(context, JarvisVoiceService::class.java)
                    .setAction(ACTION_STOP)
            )
        }

        fun isActive(context: Context): Boolean =
            context.getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(ACTIVE, false)
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var active = false
    private var shuttingDown = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> deactivate()
            else -> activate()
        }
        return START_STICKY
    }

    private fun activate() {
        shuttingDown = false
        active = true
        saveActive(true)

        startForeground(
            NOTIFICATION_ID,
            notification("Active — say JARVIS")
        )
        scheduleRecognition(300L)
    }

    private fun deactivate() {
        shuttingDown = true
        active = false
        saveActive(false)

        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null

        tts?.stop()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun saveActive(value: Boolean) {
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit()
            .putBoolean(ACTIVE, value)
            .apply()
    }

    private fun scheduleRecognition(delayMs: Long) {
        handler.removeCallbacksAndMessages(null)
        if (!active || shuttingDown) return

        handler.postDelayed({
            if (active && !shuttingDown) startRecognition()
        }, delayMs)
    }

    private fun startRecognition() {
        if (!active || shuttingDown) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            scheduleRecognition(3000L)
            return
        }

        recognizer?.cancel()
        recognizer?.destroy()

        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onPartialResults(partialResults: android.os.Bundle?) = Unit
            override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit

            override fun onEndOfSpeech() {
                scheduleRecognition(250L)
            }

            override fun onError(error: Int) {
                scheduleRecognition(900L)
            }

            override fun onResults(results: android.os.Bundle?) {
                val spoken = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()

                handleSpeech(spoken)
                if (active && !shuttingDown) scheduleRecognition(350L)
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

        try {
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleRecognition(1500L)
        }
    }

    private fun handleSpeech(spoken: String) {
        if (spoken.isBlank() || !active || shuttingDown) return

        val normalized = spoken
            .lowercase(Locale.getDefault())
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        // Privacy command is recognized before the wake-word requirement.
        if (normalized.contains("code 101") ||
            normalized.contains("code one zero one")
        ) {
            speak("Code 101 acknowledged. Microphone offline.")
            handler.postDelayed({ deactivate() }, 700L)
            return
        }

        val wakeIndex = normalized.indexOf(WAKE)
        if (wakeIndex < 0) return

        val command = normalized
            .substring(wakeIndex + WAKE.length)
            .trim()

        if (command.isBlank()) {
            speak("Yes?")
            return
        }

        execute(command)
    }

    private fun execute(command: String) {
        val response = JarvisCommandEngine.execute(this, command)
        speak(response)
    }

    private fun speak(text: String) {
        if (!active || shuttingDown) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun notification(text: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            1,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                    PendingIntent.FLAG_IMMUTABLE else 0
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "JARVIS Voice",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
