package com.esn.jarvis

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import java.util.Locale

object JarvisCommandEngine {

    fun execute(context: Context, raw: String): String {
        val original = raw.trim()
        val command = original.lowercase(Locale.getDefault()).trim()
        if (command.isBlank()) return "I didn't catch that."

        return when {
            command == "stop listening" ||
            command == "go offline" ||
            command == "sleep" -> {
                JarvisVoiceService.requestPrivacyMode(context)
                "Going offline."
            }

            command.contains("open settings") -> {
                context.startActivity(
                    Intent(Settings.ACTION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "Opening settings."
            }

            command == "home" || command.contains("go home") ->
                if (JarvisAccessibilityService.home()) "Going home."
                else "Phone access is not enabled."

            command == "back" || command.contains("go back") ->
                if (JarvisAccessibilityService.back()) "Going back."
                else "Phone access is not enabled."

            command == "recents" ||
            command.contains("recent apps") ||
            command.contains("show recent apps") ->
                if (JarvisAccessibilityService.recents()) "Showing recent apps."
                else "Phone access is not enabled."

            command == "scroll down" || command.contains("scroll down") ->
                if (JarvisAccessibilityService.scrollForward()) "Scrolling down."
                else "I couldn't scroll the current screen."

            command == "scroll up" || command.contains("scroll up") ->
                if (JarvisAccessibilityService.scrollBackward()) "Scrolling up."
                else "I couldn't scroll the current screen."

            command.startsWith("click ") || command.startsWith("tap ") -> {
                val target = original.substringAfter(" ").trim()
                if (JarvisAccessibilityService.clickText(target)) {
                    "Clicked $target."
                } else {
                    "I couldn't find a clickable $target on the current screen."
                }
            }

            command.startsWith("type ") || command.startsWith("enter ") -> {
                val text = original.substringAfter(" ").trim()
                if (JarvisAccessibilityService.typeText(text)) {
                    "Text entered."
                } else {
                    "I couldn't find an editable field on the current screen."
                }
            }

            command.contains("read screen") ||
            command.contains("what is on my screen") ||
            command.contains("read what's on screen") -> {
                val screen = JarvisAccessibilityService.readScreen()
                if (screen.isBlank()) "I can't read the current screen."
                else screen.take(1200)
            }

            command.contains("volume up") ||
            command.contains("turn the volume up") ->
                adjustVolume(context, AudioManager.ADJUST_RAISE, "Volume increased.")

            command.contains("volume down") ||
            command.contains("turn the volume down") ->
                adjustVolume(context, AudioManager.ADJUST_LOWER, "Volume decreased.")

            command.contains("mute") -> {
                audio(context).adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                "Muted."
            }

            command.contains("unmute") -> {
                audio(context).adjustVolume(AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                "Unmuted."
            }

            command.startsWith("search youtube for ") -> {
                val q = original.substringAfter("search youtube for ", "").trim()
                if (q.isBlank()) "Tell me what to search for."
                else {
                    openUrl(context, "https://www.youtube.com/results?search_query=${Uri.encode(q)}")
                    "Searching YouTube for $q."
                }
            }

            command.startsWith("search the web for ") ||
            command.startsWith("search for ") ||
            command.startsWith("google ") -> {
                val q = when {
                    command.startsWith("search the web for ") ->
                        original.substringAfter("search the web for ", "").trim()
                    command.startsWith("search for ") ->
                        original.substringAfter("search for ", "").trim()
                    else ->
                        original.substringAfter("google ", "").trim()
                }
                if (q.isBlank()) "Tell me what to search for."
                else {
                    openUrl(context, "https://www.google.com/search?q=${Uri.encode(q)}")
                    "Searching the web for $q."
                }
            }

            command == "open discord" -> launchNamedApp(context, "Discord")
            command == "open youtube" -> launchNamedApp(context, "YouTube")
            command == "open chrome" -> launchNamedApp(context, "Chrome")
            command.startsWith("open ") -> {
                val name = original.substringAfter("open ", "").trim()
                if (name.isBlank()) "Tell me which app to open."
                else launchNamedApp(context, name)
            }

            else -> "I heard you, but I don't have a skill for that command yet."
        }
    }

    private fun adjustVolume(context: Context, direction: Int, response: String): String {
        audio(context).adjustVolume(direction, AudioManager.FLAG_SHOW_UI)
        return response
    }

    private fun audio(context: Context): AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun openUrl(context: Context, url: String) {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun launchNamedApp(context: Context, requestedName: String): String {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(0)
        val target = requestedName.lowercase(Locale.getDefault())

        val match = apps.firstOrNull { app ->
            pm.getApplicationLabel(app).toString()
                .lowercase(Locale.getDefault())
                .contains(target)
        }

        if (match != null) {
            val intent = pm.getLaunchIntentForPackage(match.packageName)
            if (intent != null) {
                context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return "Opening ${pm.getApplicationLabel(match)}."
            }
        }

        return "I couldn't find an installed app named $requestedName."
    }
}
