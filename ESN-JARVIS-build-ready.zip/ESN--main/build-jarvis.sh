#!/usr/bin/env bash
set -euo pipefail
echo "Building JARVIS debug APK..."
gradle assembleDebug
echo
echo "APK:"
echo "app/build/outputs/apk/debug/app-debug.apk"
